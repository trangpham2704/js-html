<?php

namespace App\Providers;

use App\Models\ProductType;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Session;
use App\Models\Cart;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();
        view()->composer("Layouts.header", function ($view) {
            $loaisanpham = ProductType::all();
            $view->with("loaisanpham", $loaisanpham);
        });
        view()->composer(['Layouts.header', 'Pages.dathang'], function($view) {
            if (Session('cart')) {
                $oldcart = Session::get('cart');
                $cart = new Cart($oldcart);
                $view->with(['cart' => Session::get('cart'), 'product_cart' => $cart->items,
                'totalPrice' => $cart->totalPrice, 'totalQty' => $cart->totalQty]);
            }
            });
    }
}
