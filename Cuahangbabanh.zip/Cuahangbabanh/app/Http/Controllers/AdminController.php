<?php

namespace App\Http\Controllers;
use App\Models\Bill;
use App\Models\Customer;
use App\Models\Bill_detail;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\ProductType;
use Illuminate\Support\Str;
use App\Models\Product;
use Facade\FlareClient\View;

use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function getDanhSachKhachHang(){
        $khachhang = Customer::all();
        return view("Admin.Custume_danhsach", compact("khachhang"));
    }
    public function getDanhSachSanPham(){
        $sanpham = Product::all();
       return view("Admin.Product_danhsach", compact("sanpham"));
    }
    public function getLoai($idtl)
    {
        $loaisp = ProductType::where("id_type", $idtl)->get();
        foreach ($loaisp as $lt) {
            echo "<option value='" . $lt->id . "'>" . $lt->name . "</option>";
        }
    }
    public function getThemsp()
    {
      
        $loaisp = ProductType::all();
        return view("Admin.Product_them", compact("loaisp"));  
    }
    public function postThemsp(Request $req)
            {
             

                $val = $req->validate([
                
                "ten" => 'required|min:3|max:100',
                "loaisp" => 'required',
                "gia"=> 'required',
                "sale"=> 'required',
                "noidung" => "required",
                "unit" => "required"

                ],[
                "ten.required" => "Bạn chưa nhập tên loại tin",
                "ten.min" => "Tên  tối thiểu 3 ký tự",
                "ten.max" => "Tên  tối đa 100 ký tự",
                "gia.required"=>"Không được để trống",
                "sale.required"=>"Không được để trống",
                "unit.required"=>"Không được để trống",
                "noidung.required"=>"Không được để trống",
                "loaisp.required"=>"Chưa chọn thể loại"

                ]);
                $sanpham = new Product();
                $sanpham->name=$val["ten"];
                $sanpham->id_type = $val["loaisp"];
                $sanpham->unit_price=$val["gia"];
                $sanpham->promotion_price=$val["sale"];
                $sanpham->unit=$val["unit"];
                $sanpham->new=1;
                $sanpham->description = $val["noidung"];
  
                if ($req->hasFile("hinh"))
                {
                    $file = $req->file("hinh");
                    $ext = $file->getClientOriginalExtension();
                            if ($ext != "jpg" && $ext != "png" && $ext != "jpeg")
                        {
                                return redirect("Admin/sanpham/them")->with("loi", "Bạn chỉ được chọn file hình có: .jpg, .png, .jpeg");
    
                        }
                                $ten = $file->getClientOriginalName();
                                $name = Str::random(4);
                                $name = $name."_".$ten;
                            while(file_exists("../resources/FrontEnd/image/product".$name))
                        {
                                $name = Str::random(4);
                                $name = $name."_".$ten;
                        }
                            $file->move("../resources/FrontEnd/image/product", $name);
                            $sanpham->image = $name;
                    }
                else
                        {
                                $sanpham->image = "";
                 }
                $sanpham->save();
                return redirect("Admin/sanpham/them")->with("thongbao", "Thêm mới thàng công");
            }
            public function getXoasanpham($id)
            {
                $tl = Product::find($id);
                $tl->delete();
                return redirect("Admin/sanpham/danhsach")->with("thongbao", "Xoá  loại sản phẩm thành
                công");
            }

    public function getDanhSachDonHang()
    {
        $donhang = Bill::join('Customer','Customer.id','=', 'bills.id_customer')->get();
        return view("Admin.Billdanhsach", compact("donhang"));
        }
        public function getCapNhatDonHang($id)
        {
        $dhg = Bill::find($id);
        $cus = Customer::find($dhg->id_customer);
        $ct_dhg = Bill_detail::where("id_bill", "=", $dhg->id)
        ->join("products", "products.id", "=", "Bill_Detail.id_product")
        ->get(['products.name', 'bill_detail.quantity', 'bill_detail.unit_price']);
        return view("Admin.Billchitiet", compact("dhg", "cus", "ct_dhg"));
        }
        public function getCapNhatKhachHang($id)
        {
        $cus = Customer::find($id);
        return view("Admin.Custume_chitiet", compact("cus"));
        }
        public function postCapNhatDonHang(Request $req, $id)
        {
        $dhg = Bill::find($id);
        $dhg->state = $req->state;
        $dhg->save();
        return redirect()->back()->with("thongbao", "đã cập nhật đơn hàng này !!!");
        }
        public function getDanhSachTheLoai()
            {
                $theloai = ProductType::all();
                return view("Admin.Product_typedanhsach", compact("theloai"));
            }
            public function getXoaTheLoai($id)
            {
                $tl = ProductType::find($id);
                $tl->delete();
                return redirect("Admin/theloai/danhsach")->with("thongbao", "Xoá  loại sản phẩm thành
                công");
            }
            public function getThemTheLoai()
    {
            return view("Admin.Product_typeThem");
    }
    public function postThemTheLoai(Request $req)
    {
        $val = $req->validate([
           
            "tieude" => "required|min:3",
           
            "noidung" => "required"
            ],[
            
            "tieude.required" => "Bạn chưa nhập tiêu",
            "tieude.min" => "Tiêu đề ít nhất 3 ký tự",
           
           
            "noidung.required" => "Bạn chưa nhập nội dung"

            ]);
        $tt = new ProductType();
        $tt->name = $val["tieude"];
      
        $tt->description = $val["noidung"];
  
            if ($req->hasFile("hinh"))
            {
                $file = $req->file("hinh");
                $ext = $file->getClientOriginalExtension();
                        if ($ext != "jpg" && $ext != "png" && $ext != "jpeg")
                    {
                            return redirect("Admin/theloai/them")->with("loi", "Bạn chỉ được chọn file hình có: .jpg, .png, .jpeg");

                    }
                            $ten = $file->getClientOriginalName();
                            $name = Str::random(4);
                            $name = $name."_".$ten;
                        while(file_exists("../resources/FrontEnd/image/product".$name))
                    {
                            $name = Str::random(4);
                            $name = $name."_".$ten;
                    }
                        $file->move("../resources/FrontEnd/image/product", $name);
                        $tt->image = $name;
                }
            else
                    {
                            $tt->image = "";
             }
                $tt->save();
                return redirect("Admin/theloai/them")->with("thongbao", "Thêm  thành công");
            }
            

            public function getSuaTheLoai($id)
            {
              
                   
                    $theloai = ProductType::find($id);
                    return view("Admin.Product_typeSua", compact("theloai"));
            }
            public function getSuasp($id)
            {

        $loaisp = ProductType::all();     
                    $sanpham = Product::find($id);
                    return view("Admin.Product_sua", compact("sanpham" ,"loaisp"));
            }
            public function postSuasp(Request $req, $id)
    {
         $val = $req->validate([
                
                "ten" => 'required|min:3|max:100',
                "loaisp" => 'required',
                "gia"=> 'required',
                "sale"=> 'required',
                "noidung" => "required",
                "unit" => "required"

                ],[
                "ten.required" => "Bạn chưa nhập tên loại tin",
                "ten.min" => "Tên  tối thiểu 3 ký tự",
                "ten.max" => "Tên  tối đa 100 ký tự",
                "gia.required"=>"Không được để trống",
                "sale.required"=>"Không được để trống",
                "unit.required"=>"Không được để trống",
                "noidung.required"=>"Không được để trống",
                "loaisp.required"=>"Chưa chọn thể loại"

                ]);
                $sanpham =  Product::find($id);
                $sanpham->name=$val["ten"];
                $sanpham->id_type = $val["loaisp"];
                $sanpham->unit_price=$val["gia"];
                $sanpham->promotion_price=$val["sale"];
                $sanpham->unit=$val["unit"];
              
                $sanpham->description = $val["noidung"];
       
        if ($req->hasFile("hinh"))
        {
            $file = $req->file("hinh");
            $ext = $file->getClientOriginalExtension();
            if ($ext != "jpg" && $ext != "png" && $ext != "jpeg")
            {
                return redirect("Admin/sanpham/them")->with("loi", "Bạn chỉ được chọn
                
                file hình có: .jpg, .png, .jpeg");
            
            }
            $ten = $file->getClientOriginalName();
            $name = Str::random(4);
            $name = $name."_".$ten;
            while(file_exists("../resources/FrontEnd/image/product".$name))
            {
                $name = Str::random(4);
                $name = $name."_".$ten;
            }
                $file->move("../resources/FrontEnd/image/product", $name);
                $sanpham->image= $name;
        }
        else
        {
            $sanpham->image = "";
        }
        $sanpham->save();
        return redirect("Admin/sanpham/sua/".$id)->with("thongbao", "Sửa  san pham thành
        công");
        }
public function postSuaTheLoai(Request $req, $id)
    {
        $val = $req->validate([
        
        "tieude" => "required|min:3",
       
        "noidung" => "required"
        ],[
        
        "tieude.required" => "Bạn chưa nhập tiêu",
        
        "tieude.min" => "Tiêu đề ít nhất 3 ký tự",
       
        "noidung.required" => "Bạn chưa nhập nội dung"
        ]);
        $tt = ProductType::find($id);
        $tt->name = $val["tieude"];
        
        $tt->description = $val["noidung"];
       
        if ($req->hasFile("hinh"))
        {
            $file = $req->file("hinh");
            $ext = $file->getClientOriginalExtension();
            if ($ext != "jpg" && $ext != "png" && $ext != "jpeg")
            {
                return redirect("Admin/theloai/them")->with("loi", "Bạn chỉ được chọn
                
                file hình có: .jpg, .png, .jpeg");
            
            }
            $ten = $file->getClientOriginalName();
            $name = Str::random(4);
            $name = $name."_".$ten;
            while(file_exists("../resources/FrontEnd/image/product".$name))
            {
                $name = Str::random(4);
                $name = $name."_".$ten;
            }
                $file->move("../resources/FrontEnd/image/product", $name);
                $tt->image= $name;
        }
        else
        {
            $tt->image = "";
        }
        $tt->save();
        return redirect("Admin/theloai/sua/".$id)->with("thongbao", "Sửa loai san pham thành
        công");
        }
        public function getDangNhap()

        {
        return view("Admin.login");
        }
        public function postDangNhap(Request $req)
        {
        $req->validate(
        
        [
        'email' => 'required|email',
        'password' => 'required|min:6|max:20'
        ],
        [
        'email.required' => "chưa nhập địa chỉ mail",
        'email.email' => "Địa chỉ mail không đúng định dạng",
        'password.required' => 'Chưa nhập mật khẩu',
        'password.min' => 'mật khẩu tối thiểu 6 ký tự',
        'password.max' => 'mật khẩu tối đa 20 ký tự'
        ]
        );
        $chungthuc = array('email' => $req->email, 'password' => $req->password);
        if (Auth::attempt($chungthuc)) {
        return view("Admin.thongtin");
        } else {
        return redirect()->back()->with(['matb' => '0', 'noidung' => 'Đăng nhập thất bại']);
        }
        }
    public function getLogout()
    {
            Auth::logout();
            return view("Admin.login");
    }
    public function getUserInfo()
    {
    if (Auth::check())
    {
    return view("Admin.thongtin");
    }
    else
    {
    return redirect("Admin/login");
    }
    }

}
