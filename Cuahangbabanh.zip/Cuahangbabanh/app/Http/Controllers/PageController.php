<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Bill_detail;
use App\Models\Product;
use App\Models\ProductType;
use App\Models\Slide;
use Illuminate\Http\Request;
use App\Models\Bill;
use App\Models\Cart;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{
    public function getTrangchu()
    {
        $slide = Slide::all();
        $newsp = Product::where("new", "=", 1)->paginate(4);
        $spsale = Product::where("promotion_price", "!=", 0)->paginate(8);
        return view("Pages.trangchu", compact("slide", "newsp", "spsale"));
    }

    public function getLoaiSP($id)
    {
        $loai = ProductType::where("id", "=", $id)->first();
        $dsloai = ProductType::all();
        $sptheoloai = Product::where("id_type", "=", $id)->get();
        $spkhac = Product::where("id_type", "=", $id)->paginate(6);
        return view("Pages.loaisanpham", compact("loai", "dsloai", "sptheoloai", "spkhac"));
    }
    public function getChitietSp($id)
    {
        $sanpham = Product::where("id", "=", $id)->first();
        $sptuongtu = Product::where("id_type", "=", $sanpham->id_type)->paginate(3);
        $spmoi = Product::where("new", "=", 1)->take(4)->get();
        $spbanchay = Bill_detail::selectRaw("id_product,sum(quantity)as total")
            ->groupBy("id_product")
            ->orderByDesc("total")->take(4)->get();
        return view("Pages.chitietsanpham", compact("sanpham", "sptuongtu", "spmoi", "spbanchay"));
    }
    public function getThemVaoGio(Request $req, $id)

    {
    $sanpham =Product::find($id);
    $oldcart = Session('cart')? Session::get('cart') : null;
    $cart = new Cart($oldcart);
    $cart->add($sanpham, $id);
    $req->session()->put('cart', $cart);
    return redirect()->back();
    }
    public function getXoaGio($id)
    {
    $oldcart = Session('cart') ? Session::get("cart") : null;
    $cart = new Cart($oldcart);
    
    $cart->reduceByOne($id);
    if (count($cart->items)>0)
    {
    Session::put('cart', $cart);
    }
    else
    {
    Session::forget("cart");
    }
    return redirect()->back();
    }
    public function getLienhe()
    {
        return view("Pages.lienhe");
    }
    public function getDangnhap()
    {
        return view("Pages.login");
    }
    public function postdangnhap(Request $req)
    {
          $this->validate( $req,[
             'email'=>'required',
             'password'=>'required|min:8|max:32'
            ],[
             'email.required'=>'bạn chưa nhập email',
             'password.required'=>'bạn chưa nhập password',
             'password.min'=>'password không được nhỏ hơn 8 ký tự',
             'password.max'=>'password không được lớn hơn 32 ký tự'
            ]);
        $chungthuc = array('email' => $req->email, 'password' => $req->password);
        if(Auth::attempt($chungthuc)){
            return view("Pages.gioithieu");
        }
        else{
            return redirect()->back()->with(['matb' => '0', 'noidung' => 'Đăng nhập thất bại']);
        }

    }
   
    public function postDangky(Request $req)
    {
        $validate = $req->validate([
        
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|max:32',
            'repassword' => 'required|same:password',
            'address'=>'required',
            'fullname'=>'required'
            
        ], [
               
                'email.required' => 'Chưa nhập email của bạn',
                'email.email' => 'Bạn chưa nhập đúng định dạng email',
                'email.unique' => 'Email này đã có người đăng ký rồi',
                'password.required' => 'Bạn chưa nhập mật khẩu',
                'password.min' => 'Mật khẩu phải ít nhất 8 ký tự',
                'password.max' => 'Mật khẩu chỉ tối đa 32 ký tự',
                'repassword.required' => 'Bạn chưa nhập lại mật khẩu',
                'repasswordAgain.same' => 'Mật khẩu nhập lại không khớp',
                'address.required' => 'Chưa nhập địa chỉ của bạn',
                'fullname.required' => 'Chưa nhập tên của bạn'
                
                
            ]);
            $user=new User;
        $user->full_name = $req->fullname;
        $user->email = $req->email;
        $user->password =Hash::make($req->password);
        $user->phone = $req->phone;
        $user->address= $req->address;
        $user->save();
        return redirect()->back()->with("thongbao","Chúc mừng bạn đã đăng ký thành công ");

    }

    public function getDangxuat()
    {
             Auth::logout();
            return view("Pages.gioithieu");
            }

    public function getDangky()
    {
        return view("Pages.dangky");
    }
    public function getGioithieu()
    {
        return view("Pages.gioithieu");
    }
    public function getDatHang()
    {
        return view("Pages.dathang");
    }
    public function postDatHang(Request $req)
    {
        $cart = Session::get('cart');
        //lưu thông tin khách hàng
        $cus = new Customer();
        $cus->name = $req->name;
        $cus->gender = $req->gender;
        $cus->email = $req->email;

        $cus->address = $req->address;
        $cus->phone_number = $req->phone_number;
        $cus->note = $req->note;
        $cus->save();
        //lưu thông tin đơn hàng
        $bill = new Bill();
        $bill->id_customer = $cus->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $cart->totalPrice;
        $bill->payment = $req->payment;
        $bill->note = $req->note;
        $bill->save();
        //lưu thông tin chi tiết đơn hàng
        foreach ($cart->items as $key => $value) {
            $bd = new Bill_detail();
            $bd->id_bill = $bill->id;
            $bd->id_product = $key;
            $bd->quantity = $value["qty"];
            $bd->unit_price = ($value["price"] / $value["qty"]);
            $bd->save();
        }
        Session::forget('cart');
        return view("Pages.notify");
    }
    public function getTimkiem(Request $req){
        $sptk = Product::where("name", "like", "%". $req->key."%")->orwhere("unit_price", $req->key)->get();
        return view("Pages.timkiem", compact("sptk"));
    }
}