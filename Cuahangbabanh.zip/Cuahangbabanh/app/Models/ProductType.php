<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductType extends Model
{
    use HasFactory;
    protected $primaryKey="id";
    public $timestamps=false;

    protected $table = "type_products";
public function products(){
        return $this->hasMany(Product::class, "id_type", "id");
}

}
