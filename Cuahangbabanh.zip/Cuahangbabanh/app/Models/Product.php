<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    protected $table = "products";
    protected $primaryKey="id";
    public $timestamps=false;

    public function product_type(){
        return $this->belongsTo(ProductType::class, "id_type", "id");
    }
    public function bill_detail(){
        return $this->hasMany(Bill_detai::class, "id_product", "id");
    }
}
