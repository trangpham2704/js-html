@extends("Layout.master")
@section("content")
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                <h1 class="page-header"> Sản phẩm
                <small>Thêm mới</small>
                </h1>
                </div>
                <!-- /.col-lg-12 -->
                <div class="col-lg-7" style="padding-bottom:120px">
          @if(count($errors)>0)
                <div class="alert alert-danger">
         @foreach($errors->all() as $err)
                {{$err}}<br>
         @endforeach
                </div>
          @else
         @if (session('thongbao'))
                <div class="alert alert-success">
                {{session('thongbao')}}
                </div>
         @endif
        @endif
                <form action="{{route('them_sanpham')}}" method="POST">
                @csrf
                <div class="form-group">
                <label>Tên sản phẩm</label>
                <input class="form-control" name="ten" placeholder="Vui lòng nhập tên sản phẩm " />
                
</div>
                <div class="form-group">
                <label>Gía</label>
                <input class="form-control" name="gia" placeholder="Vui lòng nhập giá sản phẩm " />
                </div>
                <div class="form-group">
                <label>Gía giảm</label>
                <input class="form-control" name="sale" placeholder="Vui lòng nhập gia sale sản phẩm " />
                </div>
                <div class="form-group">
                <label>Unit</label>
                <input class="form-control" name="unit" placeholder="Vui lòng nhập unit sản phẩm " />
                </div>
                <div class="form-group">

                <label>Tên Thể Loại</label>
                <select class="form-control" name="loaisp">

@foreach($loaisp as $tl)
<option value="{{$tl->id}}">{{$tl->name}}</option>
@endforeach
</select>

<div class="form-group">
        <label>Nội Dung</label>
        <textarea name="noidung" class="form-control ckeditor"
        rows="5"></textarea>
        </div>
        <div class="form-group">
        <label>Hình ảnh</label>
        <input type="file" class="form-control" name="hinh"
        value=""/>
        </div>
                <button type="submit" class="btn btn-default">Thêm</button>
                <button type="reset" class="btn btn-default">Làm mới</button>
                <form>
                </div>
            </div>
        <!-- /.row -->
        </div>
    <!-- /.container-fluid -->
    </div>
@endsection
