@extends("Layout.master")
@section("content")
        <div id="page-wrapper">
        <div class="container-fluid">
                <div class="row">
                <div class="col-lg-12">
                <h1 class="page-header"> Sản Phẩm
                <small>Danh sách</small>
                </h1>
                </div>
                <!-- /.col-lg-12 -->
                @if (session('thongbao'))
                <div class="alert alert-success">
                {{session('thongbao')}}
                </div>
        @endif
                <table class="table table-striped table-bordered table-hover"id="dataTables-example">
                <thead>
                <tr align="center">
                <th>ID</th>
                <th>Tên sản phẩm</th>
                <th>Gía</th>
                 <th>Gía giảm</th>
                <th>Loại sản phẩm</th>
                <th>Hình</th>
                <th>Delete</th>
                <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                @foreach($sanpham as $tt)
                <tr class="odd gradeX" align="center">
                <td>{{$tt->id}}</td>
                <td>{{$tt->name}}</td>
                <td>{{$tt->unit_price}}</td>
                <td>{{$tt->promotion_price}}</td>
            
                <td>{{$tt->product_type->name}}</td>

                <td>  <img class="img-responsive" src="../resources/FrontEnd/image/product/{{$tt->image}}" width="60px" height="50px" alt=""></td>  
                <td class="center"><i class="fa fa-trash-o fa-fw"></i>
                <a href="{{route('xoa',$tt->id)}}">Xoá</a>
                </td>

                <td class="center"><i class="fa fa-pencil fa-fw"></i>
                 <a href="{{route('sua_sanpham',$tt->id)}}">Sửa</a>
                </td>

                </tr>
                @endforeach
                </tbody>
                </table>
        </div>
        <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
        </div>
@endsection
