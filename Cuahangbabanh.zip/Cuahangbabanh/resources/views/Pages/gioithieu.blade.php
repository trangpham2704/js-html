@extends("Layouts.master")
 @section("content")
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Giới thiệu</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="{{route('trangchu')}}">Home</a> / <span>Giới thiệu</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="container">
		<div id="content">
			<div class="our-history">
				<h2 class="text-center wow fadeInDown">	Các cửa hàng bán bánh nổi bật trong năm 2022</h2>
				<div class="space35">&nbsp;</div>

				<div class="history-slider">
					<div class="history-navigation">
						<a data-slide-index="0" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> Palais des Douceurs</span></a>
						<a data-slide-index="1" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> Tours Les Jours</span></a>
						<a data-slide-index="2" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> Givral Bakery</span></a>
						<a data-slide-index="3" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> Le Petit Bake&Cake</span></a>
						<a data-slide-index="4" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center">  L’Usine Cafe</span></a>
						<a data-slide-index="5" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> Ivoire</span></a>
						<a data-slide-index="6" href="blog_with_2sidebars_type_e.html" class="circle"><span class="auto-center"> My shop</span></a>
					</div>

					<div class="history-slides">
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h1.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title">Palais des Douceurs</h5>
								<p>
Địa chỉ: First Floor, 87 Nguyễn Trãi, Phường Phạm Ngũ Lão, Quận 1, Thành phố Hồ Chí Minh <br>
SĐT: 028 3925 2779
								</p>
								<div class="space20">&nbsp;</div>
								<p>Palais des Douceurs nằm trên đường Nguyễn Trãi, Quận 1. Tiệm bánh mang đậm phong cách châu Âu cả từ bài trí đến hương vị của những món bánh signature. Các món bánh ở đây dịu dàng, ngọt ngào, nhưng không kém phần sang trọng và quý phái. Đến với Palais des Douceurs, các tín đồ hảo ngọt không chỉ thỏa mãn được vị giác của mình, mà còn mãn nhãn với những món bánh được trình bày tinh tế đến nghệ thuật.
<br>
Những hương vị mà chắc chắn bạn sẽ lưu luyến gồm rất nhiều cái tên: mascarpone Ý, mousse vani Bourbon, bánh vani mềm, Apple & Assam tea Tiramisu. Tuy nhiên, đến đây bạn không thể bỏ qua Rose Litchi. Đây là một chiếc bánh giản dị trong hình thức nhưng đầy bất ngờ và ngập tràn cảm xúc trong hương vị. Chính điều này đã tạo nên chiếc bánh đẳng cấp, vĩnh cửu trong lòng mọi tín đồ bánh ngọt toàn thế giới.</p>
							</div>
							</div> 
						</div>
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h2.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title">Tours Les Jours</h5>
								<p>
								Địa chỉ: Số 1 Cao Thắng, P.2, Q.3
                                Điện thoại: 028 3830 8120 <br>
								</p>
								<div class="space20">&nbsp;</div>
								<p>Cửa hàng bánh ngọt TPHCM không kém phần hấp dẫn chính là Tous Les Jours. Đây là thương hiệu bán lẻ của Hàn Quốc khá nổi tiếng tại Việt Nam, với lượng người hâm mộ đông đảo. Vào những dịp đặc biệt như sinh nhật, ai cũng mong muốn được thưởng thức một miếng bánh Tous Les Jours. Có rất nhiều loại bánh để lựa chọn, vì bánh được làm sẵn nên không cần đặt trước; chỉ cần đi bộ vào cửa hàng và thực hiện lựa chọn của bạn.
<br>
Mặc dù giá bán có nhỉnh hơn một chút so với một số thương hiệu bánh khác (100.000 đồng/ 2 người; bánh kem giá khoảng 280.000/ 1 cái), nhưng bù lại chất lượng lại cực kỳ cao. Bánh ẩm và thơm, được làm từ nguyên liệu tươi. Tours Les Jours đặc biệt chú trọng khâu trang trí, làm cho chiếc bánh trở nên tinh tế và sang trọng, chúng thay đổi theo mùa, lễ hội và các dịp đặc biệt khác. </p>
							</div>
							</div> 
						</div>
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h3.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title">Givral Bakery</h5>
								<p>
								Địa chỉ: 114 Hàm Nghi, Phường Bến Nghé, Quận 1 <br>
Điện thoại: 028 3868 4377 <br>
Website: https://givralbakery.com.vn/
								</p>
								<div class="space20">&nbsp;</div>
								<p>Givral Bakery là một trong những cửa hàng bánh ngọt TPHCM lâu năm. Địa chỉ này được biết đến là nơi mua bánh kem bắp ngon nhất, được nhiều người lựa chọn. Givral Bakery bắt đầu kinh doanh từ năm 1950 và liên tục phát triển, cung cấp thêm một loạt các loại bánh ngon khác. Tuy nhiên, bánh kem bắp tại đây vẫn là mặt hàng chủ đạo và giữ được chất riêng của nó.
<br>
Đến với Givral Bakery, bạn sẽ có cơ hội thưởng thức Bánh Kem Bắp Givral vô cùng nổi tiếng tại Sài Thành. Vị thơm nhẹ và bông xốp của bánh kem, kết hợp với những hạt bắp mềm mịn và lớp kem béo nhẹ, sẽ khiến cho bạn khó quên nếu đã từng một lần được nếm thử.</p>
							</div>
							</div> 
						</div>
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h4.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title">Le Petit Bake & Cake</h5>
								<p>
								Địa chỉ: 115 Hồ Tùng Mậu, quận 1, Tp. HCM <br>
Điện thoại: (028)73080099 Ext: 8501 <br>
Website: https://innsaigon.com/le-petit-bakecake/
								</p>
								<div class="space20">&nbsp;</div>
								<p>Le Petit Bake & Cake là cửa hàng bánh ngọt TPHCM ngon nhất, thu hút được rất nhiều sự quan tâm của cộng đồng làm bánh tính đến thời điểm hiện tại. Đầu bếp trưởng của Le Petit là người tài năng, được đào tạo theo tiêu chuẩn của Pháp và có nhiều năm kinh nghiệm setup bếp bánh tại các nhà hàng bánh cao cấp tại Sài Gòn. Anh đã và đang nỗ lực đưa tiêu chuẩn bánh 5 sao đến gần hơn với khách hàng bằng nhiều hình thức khác nhau.
<br>
Le Petit Bake & Cake chỉ sử dụng những nguyên liệu cao cấp nhất của nước ngoài, cùng với những trái cây tươi ngon nhất của Việt Nam, để đảm bảo rằng mỗi chiếc bánh được sản xuất ra là một tuyệt tác thực sự. Mặt hàng chính tại đây là những chiếc bánh nhỏ, không chỉ hấp dẫn về mặt thị giác mà còn lôi cuốn trong từng hương vị. Quá trình nướng bánh tỉ mỉ, sự sáng tạo trong việc kết hợp các thành phần, hương vị và kết cấu của từng lớp bánh đều thể hiện sự xuất sắc và hoàn hảo.</p>
							</div>
							</div> 
						</div>
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h5.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title"> L’Usine Cafe</h5>
								<p>
								Địa chỉ: 19 Lê Thánh Tôn, Quận 1, TP. HCM <br>
Điện thoại: 028 3822 7188 <br>
Website: https://lusinespace.com/
								</p>
								<div class="space20">&nbsp;</div>
								<p>Trong trường hợp bạn yêu thích cửa hàng bánh ngọt TPHCM sang trọng. L’Usine Café là gợi ý thích hợp, quán cà phê – bánh ngọt này có thiết kế nội thất theo phong cách châu Âu có một không hai và nằm trong một khu dân cư nhỏ với nhiều địa điểm chụp ảnh đẹp như tranh vẽ cũng như khu bán hàng, rất thu hút.
<br>
Bánh ngọt tại L’Usine Cafe được cho là khá ngon, đặc biệt là bánh chuối, bánh nướng nhỏ, bánh sô cô la kép, v.v. Ngoài ra còn có các bữa ăn và đồ uống có nhiều natri. Bạn có thể thấy rằng sẽ có rất nhiều hoạt động để bạn tham gia, ngoài việc đơn giản là thưởng thức bánh. Các nhân viên cũng rất năng động và hoạt bát. Bởi vì chất lượng tuyệt vời của bánh, giá cả ở mức cao hơn một chút, từ khoảng 40.000 – 150.000 VND.</p>
							</div>
							</div> 
						</div>
						<div> 
							<div class="row">
							<div class="col-sm-5">
								<img src="../resources/FrontEnd/image/cuahang/h6.jpg" alt="">
							</div>
							<div class="col-sm-7">
								<h5 class="other-title">Ivoire</h5>
								<p>
								Địa chỉ: 28 Cao Bá Quát, Bến Nghé, Quận 1, Thành phố Hồ Chí Minh 
								<br>
Điện thoại: 096 659 58 57
								</p>
								<div class="space20">&nbsp;</div>
								<p>Ivoire là cửa hàng bánh ngọt TPHCM quen thuộc với nhiều bạn trẻ vì những món bánh ngọt tuyệt vời và hấp dẫn thị giác. Ivoire là một tiệm bánh có diện tích khiêm tốn, nhưng với lối trang trí lộng lẫy và sang trọng, nó đã chiếm được cảm tình của những tín đồ hảo ngọt ở khắp mọi nơi.
<br>
Đến với Ivoire, bạn sẽ được chiêm ngưỡng rất nhiều loại bánh với trang trí độc đáo. Mỗi chiếc bánh có giá khoảng 150.000 đồng. Bên cạnh đó, Ivoire còn có bán trà với giá 80.000 đồng một phần. Món bánh đặc sản của tiệm là Creme Brulee Mille Crepe, chỉ phục vụ vào Chủ Nhật. Những người quan tâm nên đến đây vào cuối tuần để thử. Xin lưu ý rằng doanh nghiệp này đóng cửa vào ngày thứ hai mỗi tuần.

</p>
							</div>
							</div> 
						</div>
					</div>
				</div>
			</div>

			<div class="space50">&nbsp;</div>
			<hr>
			<div class="space50">&nbsp;</div>
			<h2 class="text-center wow fadeInDown">Bánh yêu thương</h2>
			<div class="space20">&nbsp;</div>
			<p class="text-center wow fadeInLeft">Cửa hàng bánh ngọt TPHCM quen thuộc với nhiều bạn trẻ vì những món bánh ngọt tuyệt vời và hấp dẫn thị giác. Ivoire là một tiệm bánh có diện tích khiêm tốn, nhưng với lối trang trí lộng lẫy và sang trọng, nó đã chiếm được cảm tình của những tín đồ hảo ngọt ở khắp mọi nơi.</p>
			<div class="space35">&nbsp;</div>

			<div class="row">
				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-user"></i></p>
						<p class="beta-counter-value timer numbers" data-to="19855" data-speed="2000">19855</p>
						<p class="beta-counter-title">Clients Satisfied</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-picture-o"></i></p>
						<p class="beta-counter-value timer numbers" data-to="3568" data-speed="2000">3568</p>
						<p class="beta-counter-title">Amazing Works</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-clock-o"></i></p>
						<p class="beta-counter-value timer numbers" data-to="258934" data-speed="2000">258934</p>
						<p class="beta-counter-title">Support Hours</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-pencil"></i></p>
						<p class="beta-counter-value timer numbers" data-to="150" data-speed="2000">150</p>
						<p class="beta-counter-title">New Products</p>
					</div>
				</div>
			</div> <!-- .beta-counter block end -->

			<div class="space50">&nbsp;</div>
			<hr />
			<div class="space50">&nbsp;</div>

			<h2 class="text-center wow fadeInDownwow fadeInDown">Cửa hàng Bánh yêu thương</h2>
			<div class="space20">&nbsp;</div>
			<h5 class="text-center other-title wow fadeInLeft">Nổi bật</h5>
			<p class="text-center wow fadeInRight">Tiệm Bánh Su Yêu Thương là thương hiệu lâu năm và đã được sự ủng hộ và đánh giá rất cao từ rất nhiều khách hàng
			<br>	.Bạn hãy hoàn toàn yên tâm về độ tin cậy,chúng tôi đảm bảo chất lượng sản phẩm và chất lượng dịch vụ. </p>
			<div class="space20">&nbsp;</div>
			<div class="row">
				<div class="col-sm-6 wow fadeInLeft">
					<div class="beta-person media">
					
						<img class="pull-left"  width="270" height="285" src="../resources/FrontEnd/image/nhanvien/nv1.jpg" alt="">
					
						<div class="media-body beta-person-body">
							<h5>Pierre Hermé</h5>
							<p class="font-large">Picasso của thế giới bánh ngọt</p>
							<br>
							<p>Chẳng phải ngẫu nhiên mà người ta đặt biệt danh cho Pierre Hermé là “Picasso của thế giới bánh ngọt”, tay nghề làm bánh đỉnh cao của Pierre Hermé khiến làng Đầu bếp bánh phải gật gù công nhận. Hơn nữa, cách tạo ra hương vị của Pierre Hermé cũng rất phong phú và khác thường, đó là lý do ông gắn liền với cái tên “Picasso của thế giới bánh ngọt”.
Pierre Hermé là người trẻ nhất giành được danh hiệu Đầu bếp bánh ngọt xuất sắc nhất năm tại Pháp. </p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-sm-6 wow fadeInRight">
					<div class="beta-person media ">
					
						<img class="pull-left" src="../resources/FrontEnd/image/nhanvien/nv2.jpg" width="270" height="285" alt="">
					
						<div class="media-body beta-person-body">
							<h5>MGaston Lenôtre</h5>
							<p class="font-large">“đại gia” của những tiệm bánh cao cấp</p>
							<br>
							<p>Bằng những thành công của mình, Gaston Lenôtre được làng bánh ngọt thế giới trầm trồ và ngưỡng mộ. Câu chuyện theo đuổi và gắn bó dài lâu với những chiếc bánh xinh xắn của Gaston Lenôtre đã truyền cảm hứng rất lớn cho thế hệ Đầu bếp bánh tương lai. Ông cũng cho xuất bản nhiều cuốn sách hay và là chủ của chuỗi tiệm bánh cao cấp tại Paris.</p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
			</div>
			
			<div class="space60">&nbsp;</div>
			<h5 class="text-center other-title wow fadeInDown">The Best of Product</h5>
			<p class="text-center wow fadeInUp">Bánh ngọt luôn là một “liều thuốc” tốt để chữa lành tâm hồn hay giảm stress.<br> Mỗi chiếc bánh ngọt ngào, xinh xắn cũng đủ làm ta “rung động".</p>
			<div class="space20">&nbsp;</div>
			<div class="row">
				<div class="col-sm-3">
					<div class="beta-person beta-person-full">
				<div class="bets-img-hover">
						<img src="../resources/FrontEnd/image/nhanvien/b1.jpg" width="270" height="285" alt="">
				</div>
						<div class="beta-person-body">
							<h5>Bánh Macaron <br> Pháp</h5>
							<p class="font-large">bánh ngọt</p>
							<br>
							<p>Bánh Macaron được tạo từ hai miếng bánh tròn kẹp lại, vỏ bánh hơi nhám, phần đế phẳng. Bánh có độ ẩm nhẹ và mềm tan trong miệng, vị beo béo mang đầy sự ngọt ngào, đậm đà và tinh tế của lớp kem bên trong.

Bánh này còn được biến tấu theo nhiều cách khác nhau, mang theo từng hương vị đặc trưng ở mỗi quốc gia “em” có mặt như Thuỵ Sĩ, Hàn Quốc, Mỹ, Việt Nam,...</p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="beta-person beta-person-full">
					<div class="bets-img-hover">
						<img src="../resources/FrontEnd/image/nhanvien/b2.jpg" width="270" height="285" alt="">
					</div>
						<div class="beta-person-body">
							<h5>Bánh Táo Đỏ <br> Mỹ</h5>
							<p class="font-large">bánh ngọt</p>
							<br>
							<p>Bánh Táo thường có dạng lưới kết hợp với nhiều loại táo khác nhau, thường là táo tây. Bên ngoài được nướng nên có vỏ bánh có màu vàng nâu, thơm mùi bơ và giòn tan. Khi ăn vào, bạn sẽ cảm nhận được phần nhân là những miếng táo mềm, vị ngọt dịu của đường và mùi thơm từ bột quế.

Trong những ngày trời se lạnh, mưa phùn thì không gì tuyệt vời hơn là ở nhà nhâm nhi tách trà ấm và thưởng thức món bánh táo cùng những người yêu thương.

</p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="beta-person beta-person-full">
					<div class="bets-img-hover">
						<img src="../resources/FrontEnd/image/nhanvien/b3.jpg" width="270" height="285" alt="">
					</div>
						<div class="beta-person-body">
							<h5>Bánh Tiramisu <br> Itali</h5>
							<p class="font-large">bánh ngọt</p>
							<br>
							<p>Bánh có độ mềm, xốp nhất định với hương vị đặc trưng của cà phê, rượu rum. Bên trong là những lớp bánh quy xen kẽ với các lớp kem phô mai, bên ngoài được phủ bột ca cao hoặc cà phê, trông rất cuốn hút và sang trọng.

Chiếc bánh là sự quy tụ hoàn hảo của đủ các tầng vị như ngọt, béo, đắng và hương thơm của cacao, rượu rum. Có lẽ vì vậy mà nó gợi lên cho chúng ta từng cung bậc cảm xúc trong tình yêu có cả hạnh phúc lẫn niềm đau.</p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="beta-person beta-person-full">
					<div class="bets-img-hover">	
						<img src="../resources/FrontEnd/image/nhanvien/b4.jpg" width="270" height="285" alt="">
					</div>
						<div class="beta-person-body">
							<h5>Bánh Mochi <br> Nhật Bản</h5>
							<p class="font-large">bánh ngọt</p>
							<br>
							<p>Một trong các loại bánh nổi tiếng ở Nhật Bản mà bạn không thể quên thưởng thức khi tới đây là bánh Mochi. Bánh Mochi không chỉ gây ấn tượng bởi vị ngon mà nó còn mang ý nghĩa là niềm ước mơ, khao khát về cuộc viên mãn, sung túc ấm no của người dân Nhật.

Đây là loại bánh nhân ngọt, được làm từ gạo nếp dẻo thơm, vỏ bánh mềm dai.  </p>
							<a href="single_type_gallery.html">View projects <i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div> <!-- #content -->
	</div> <!-- .container -->
    @endsection