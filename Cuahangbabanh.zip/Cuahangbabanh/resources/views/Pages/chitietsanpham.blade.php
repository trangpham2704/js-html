@extends("Layouts.master")
 @section("content")
	<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Product</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="index.html">Chi tiết </a> / <span>Product</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

	<div class="container">
		<div id="content">
			<div class="row">
				<div class="col-sm-9">

					<div class="row">
						<div class="col-sm-4">
							<img src="../resources/FrontEnd/image/product/{{$sanpham->image}}" alt="">
						</div>
						<div class="col-sm-8">
							<div class="single-item-body">
								<p class="single-item-title">{{$sanpham->name}}</p>
								<p class="single-item-price">
								@if($sanpham->promotion_price==0)
													<span class="flash-sale">{{$sanpham->unit_price}} </span>
								@else
												    <span class="flash-del">{{$sanpham->unit_price}} </span>
													<span class="flash-sale">{{$sanpham->promotion_price}} </span>
													@endif
								</p>
							</div>

							<div class="clearfix"></div>
							<div class="space20">&nbsp;</div>

							<div class="single-item-desc">
								<p>Các mBánh là loại món ăn làm bằng bột mì hay bột gạo có hương vị ngọt, mặn, béo...có thể hấp, nướng, chiên,... Bánh có nhiều cách chế biến khác nhau như: rán, chiên, nướng, hấp hoặc đôi khi là ăn sống. Thành phần và nguyên liệu của bánh rất đa dạng. Ngoài thành phần chính, bánh còn một số thành phần phụ như nước dùng, rau, đồ khô, kẹo, hoặc trái cây tươi, các loại hạt, kem. Một số loại bánh còn được trang trí rất công phu, tỉ mỉ.</p>
							</div>
							<div class="space20">&nbsp;</div>

							<p>Đơn vị tính</p>
<div class="single-item-options">
							<select class="wc-select" name="unit">
<option>Size</option>
<option value="Cái" {{$sanpham->unit=="cái"?"selected" : ""}}>Cái</option>

<option value="Hộp" {{$sanpham->unit=="hộp"? "selected" : ""}}>Hộp</option>

</select>
						
								<a class="add-to-cart" href="#"><i class="fa fa-shopping-cart"></i></a>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>

					<div class="space40">&nbsp;</div>
					<div class="woocommerce-tabs">
						<ul class="tabs">
							<li><a href="#tab-description">Description</a></li>
							<li><a href="#tab-reviews">Reviews (0)</a></li>
						</ul>

					
	
					<div class="panel" id="tab-description">
<p>{!! $sanpham->description !!}</p>
</div>
</div>
<div class="space50">&nbsp;</div>
<div class="beta-products-list">

</h4>Sản phẩm tương tự</h4>

<div class="row">

@foreach($sptuongtu as $sptt)

<div class="col-sm-4">
<div class="single-item">

@if($sptt->promotion_price != 0)
<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
@endif

<div class="single-item-header">
<a href="{{route('chitietsp', $sptt->id)}}"><img src="../resources/FrontEnd/image/product/{{$sptt->image}}" height="250" alt="Hình Bánh"></a>

</div>
<div class="single-item-body">

<p class="single-item-title">{{$sptt->name}}</p>

<p class="single-item-price">

@if($sptt->promotion_price==0)
<span class="flash-sale">{{number_format($sptt->unit_price)}} đồng</span>
@else
<span class="flash-del">{{number_format($sptt->unit_price)}} đồng</span>
<span class="flash-sale">{{number_format($sptt->promotion_price)}} đồng</span>
@endif

</p>
</div>

<div class="single-item-caption">

<a class="add-to-cart pull-left" href="{{route('addtocart', $sptt->id)}}"><i class="fa fa-shopping-cart"></i></a>

<a class="beta-btn primary" href="{{route('chitietsp', $sptt->id)}}">Chi tiết <i class="fa fa-chevron-right"></i></a>

<div class="clearfix"></div>
</div>
</div>
</div>
@endforeach

</div>
<div class="row">{{$sptuongtu->links()}}</div>

</div> <!-- .beta-products-list -->
</div>
<div class="col-sm-3 aside">
<div class="widget">
<h3 class="widget-title">Sản phẩm bán chạy</h3>
<div class="widget-body">
<div class="beta-sales beta-lists">

@foreach($spbanchay as $spbc)

<div class="media beta-sales-item">

<a class="pull-left" href="route('chitietsp', $spbc->id_product)">
<img src="../resources/FrontEnd/image/product/{{$spbc->products->image}}" alt=""></a>
<div class="media-body">

{{$spbc->products->name}}<br>
@if($spbc->products->promotion_price==0)
<span class="flash-sale">{{number_format($spbc->products->unit_price)}} đồng</span>
@else
<span class="flash-del">{{number_format($spbc->products->unit_price)}} đồng</span><br>
<span class="flash-sale">{{number_format($spbc->products->promotion_price)}} đồng</span>
@endif

</div>
</div>

@endforeach

</div>
</div>
</div> <!-- best sellers widget -->
<div class="widget">
<h3 class="widget-title">Sản phẩm mới</h3>
<div class="widget-body">
<div class="beta-sales beta-lists">

@foreach($spmoi as $spm)

<div class="media beta-sales-item">

<a class="pull-left" href="{{route('chitietsp', $spm->id)}}">
<img src="../resources/FrontEnd/image/product/{{$spm->image}}" alt="">
</a>
<div class="media-body">
{{$spm->name}}<br>
@if($spm->promotion_price==0)
<span class="flash-sale">{{number_format($spm->unit_price)}} đồng</span>
@else
<span class="flash-del">{{number_format($spm->unit_price)}} đồng</span><br>
<span class="flash-sale">{{number_format($spm->promotion_price)}} đồng</span>
@endif

</div>
</div>

@endforeach

</div>
</div>
</div> <!-- best sellers widget -->

</div>
</div>
</div> <!-- #content -->
</div> <!-- .container -->
    @endsection