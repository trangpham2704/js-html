<?php
use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () { 
    return view('welcome');
});
Route::group(["prefix"=>"SHOP"],function(){
    Route::get("trangchu",[Pagecontroller::class,"getTrangchu"])->name("trangchu");
    Route::get("loaisp/{id}",[Pagecontroller::class,"getLoaiSP"])->name("loaisp");
    Route::get("timkiem",[Pagecontroller::class,"getTimkiem"])->name("timkiem");
    Route::get("gioithieu",[Pagecontroller::class,"getGioithieu"])->name("gioithieu");
    Route::get("lienhe",[Pagecontroller::class,"getLienhe"])->name("lienhe");
    Route::get("dangnhap", [Pagecontroller::class, "getDangnhap"])->name("dangnhap");
    Route::post("xulydangnhap", [Pagecontroller::class, "postDangnhap"])->name("xulydangnhap");
    Route::get("dangky", [Pagecontroller::class, "getDangky"])->name("dangky");
    Route::post("xulydangky", [Pagecontroller::class, "postDangky"])->name("xulydangky");
    Route::get("dangxuat", [Pagecontroller::class, "getDangxuat"])->name("dangxuat");
    Route::get("chitietsp/{id}",[Pagecontroller::class,"getChitietSp"])->name("chitietsp");
    Route::get("addtocart/{id}", [PageController::class, "getThemVaoGio"])->name("addtocart");  
    Route::get("removetocart/{id}", [PageController::class, "getXoaGio"])->name("removetocart");  
    Route::get("orderitem", [PageController::class, "getDatHang"])->name("orderitem");
   Route::post("xulyorderitem",[PageController::class, "postDatHang"])->name("xulyorderitem");

});
Route::group(["prefix" => "Admin"], function () {
    Route::group(["prefix" => "bills"], function(){
    Route::get("list", [AdminController::class, "getDanhSachDonHang"])->name("billslist");
    Route::get("editbills/{id}",[AdminController::class, "getCapNhatDonHang"])->name("editbills");
    Route::post("editbills/{id}",[AdminController::class, "postCapNhatDonHang"])->name("editbills");
    });
    Route::group(["prefix" => "theloai"], function(){
        Route::get("danhsach", [AdminController::class, "getDanhSachTheLoai"])->name("ds_theloai");
        Route::get("them",[AdminController::class, "getThemTheLoai"])->name("them_theloai");
        Route::post("them",[AdminController::class, "postThemTheLoai"])->name("them_theloai");
        Route::get("sua/{id}",[AdminController::class, "getSuaTheLoai"])->name("sua_theloai");
        Route::post("sua/{id}",[AdminController::class, "postSuaTheLoai"])->name("sua_theloai");
        Route::get("xoa/{id}",[AdminController::class, "getXoaTheLoai"])->name("xoa");
        });
    Route::group(["prefix" => "khachhang"], function () {
        Route::get("danhsach", [AdminController::class, "getDanhSachKhachHang"])->name("ds_khachang");
        Route::get("editKH/{id}",[AdminController::class, "getCapNhatKhachHang"])->name("editKH");
    });
    Route::group(["prefix" => "sanpham"], function () {
        Route::get("danhsach", [AdminController::class, "getDanhSachSanPham"])->name("ds_sanpham");
        Route::get("them",[AdminController::class, "getThemsp"])->name("them_sanpham");
        Route::post("them",[AdminController::class, "postThemsp"])->name("them_sanpham");
        Route::get("xoa/{id}",[AdminController::class, "getXoasanpham"])->name("xoa");
        Route::get("sua/{id}",[AdminController::class, "getSuasp"])->name("sua_sanpham");
        Route::post("sua/{id}",[AdminController::class, "postSuasp"])->name("sua_sanpham");
    });
    Route::get("infomation", [AdminController::class, "getUserInfo"])->name("info");
    
});
Route::group(["prefix"=>"nguoidung"],function(){
    Route::get("admin/login",[AdminController::class, "getDangNhap"])->name("adminlogin");
Route::post("admin/login",[AdminController::class, "postDangNhap"])->name("adminlogin");
    Route::get("logout", [AdminController::class, "getLogout"])->name("logout");
    });
    