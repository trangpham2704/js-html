 
 <?php $__env->startSection("content"); ?>
<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4>Sản phẩm tìm kiếm</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm Thấy : <?php echo e(count($sptk)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>

							<div class="row">
							<?php $__currentLoopData = $sptk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $np): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">
										<div class="single-item-header">
											<a href="<?php echo e(route('chitietsp', $np->id)); ?>"><img height="250" src="../resources/FrontEnd/image/product/<?php echo e($np->image); ?>" alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($np->name); ?> </p>
											<p class="single-item-price">
												<?php if($np->promotion_price==0): ?>
													<span class="flash-sale"><?php echo e($np->unit_price); ?> </span>
												<?php else: ?>
												    <span class="flash-del"><?php echo e($np->unit_price); ?> </span>
													<span class="flash-sale"><?php echo e($np->promotion_price); ?> </span>
													<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
 										<a class="add-to-cart" href="<?php echo e(route('addtocart', $np->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $np->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
							
								
							</div>
					
					</div>
				</div> <!-- end section with sidebar and main content -->
			</div> <!-- .main-content -->
		</div> <!-- #content  -->
	</div> <!-- .container -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Pages/timkiem.blade.php ENDPATH**/ ?>