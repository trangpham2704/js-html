
<?php $__env->startSection("content"); ?>
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="login-panel panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">THÔNG TIN NGƯỜI DÙNG</h3>
</div>
<div class="panel-body">
<form>
<fieldset>
<div class="form-group">
<label class="form-control"><?php echo e(Auth::user()->full_name); ?></label>
</div>
<div class="form-group">
<label class="form-control"><?php echo e(Auth::user()->email); ?></label>
</div>
<div class="form-group">
<label class="form-control"><?php echo e(Auth::user()->phone); ?></label>
</div>
<div class="form-group">

<label class="form-control"><?php echo e(Auth::user()->address); ?></label>
</div>
<a href="<?php echo e(route('billslist')); ?> " class="btn btn-lg btn-success btn-block">Trở về</a>
</fieldset>
</form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Admin/thongtin.blade.php ENDPATH**/ ?>