
 <?php $__env->startSection("content"); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Liên hệ</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="<?php echo e(route('trangchu')); ?>">Trang chủ</a> / <span>Liên hệ</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="beta-map">
		
		<div class="abs-fullwidth beta-map wow flipInX"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3920.2705467384494!2d106.73245461376777!3d10.713603563282179!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3175255ad7a7616b%3A0xf7e78ae276f94ca3!2zNDduIEhvw6BuZyBRdeG7kWMgVmnhu4d0LCBQaMO6IE3hu7ksIFF14bqtbiA3LCBUaMOgbmggcGjhu5EgSOG7kyBDaMOtIE1pbmgsIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1671278444532!5m2!1svi!2s" ></iframe></div>
	</div>
	<div class="container">
		<div id="content" class="space-top-none">
			
			<div class="space50">&nbsp;</div>
			<div class="row">
				<div class="col-sm-8">
					<h2>LIÊN HỆ BANHYEUTHUONG.COM:</h2>
					<div class="space20">&nbsp;</div>
					<p>Vui lòng nhập thông tin theo mẫu,
Chúng tôi sẽ liên lạc với bạn sớm nhất có thể.</p>
					<div class="space20">&nbsp;</div>
					<form action="#" method="post" class="contact-form">	
						<div class="form-block">
							<input name="your-name" type="text" placeholder="Your Name (required)">
						</div>
						<div class="form-block">
							<input name="your-email" type="email" placeholder="Your Email (required)">
						</div>
						<div class="form-block">
							<input name="your-subject" type="text" placeholder="Subject">
						</div>
						<div class="form-block">
							<textarea name="your-message" placeholder="Your Message"></textarea>
						</div>
						<div class="form-block">
							<button type="submit" class="beta-btn primary">Send Message <i class="fa fa-chevron-right"></i></button>
						</div>
					</form>
				</div>
				<div class="col-sm-4">
					<h2>Contact Information</h2>
					<div class="space20">&nbsp;</div>

					<h6 class="contact-title">Địa chỉ</h6>
					<p>
					Địa chỉ shop : 47n Hoàng Quốc Việt Quận 7 Tp Hồ Chí Minh
<br>
					Điện thoại: 0934100453
					<br>
					Email: contact@BANHyeuthuong.com
					</p>
					<div class="space20">&nbsp;</div>
					<h6 class="contact-title">Hỗ trợ</h6>
					<p>
					Thắc mắc và khiếu nại <br>
					Cam kết hài lòng 100% <br>
					Chính sách bảo mật thông tin <br>
					Chính sách và điều khoản <br>
					Hướng dẫn đặt hàng <br>
					Chính sách bảo mật thanh toán <br>
					Hướng dẫn thanh toán
		</p>
						<a href="#">contact@BANHyeuthuong.com</a>
					</p>
					<div class="space20">&nbsp;</div>
					<h6 class="contact-title">Lưu ý</h6>
					<p>
					Miễn phí giao hoa nội thành Tp. Hồ Chí Minh.<br> Các quận ngoại thành vui lòng liên hệ để biết thêm chi tiết (Giá giao sẽ từ 30.000đ-70.000đ).
						<a href="#">contact@BANHyeuthuong.com</a>
					</p>
				</div>
			</div>
		</div> <!-- #content -->
	</div> <!-- .container -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Pages/lienhe.blade.php ENDPATH**/ ?>