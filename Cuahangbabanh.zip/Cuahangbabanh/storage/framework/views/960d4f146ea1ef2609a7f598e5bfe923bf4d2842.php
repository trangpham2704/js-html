
<?php $__env->startSection("content"); ?>
<!-- Page Content -->
<div id="page-wrapper">
        <div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<h1 class="page-header">DANH SÁCH ĐƠN ĐẶT HÀNG</h1>
</div>
<!-- /.col-lg-12 -->
<table class="table table-striped table-bordered table-hover" style="font-size:12px">
<thead>
<tr align="center">
<th>Mã Đơn Hàng</th>
<th>Ngày Đặt Hàng</th>
<th>Tên Khách Hàng</th>
<th>Tổng Tiền</th>
<th>Hình Thức Thanh Toán</th>
<th>Ghi Chú</th>
<th>Trạng Thái</th>
<th>Thao tác</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="odd gradeX" align="center">
<td><?php echo e($dh->id); ?></td>
<td><?php echo e($dh->date_order); ?></td>
<td><?php echo e($dh->name); ?></td>
<td><?php echo e($dh->total); ?></td>
<td><?php echo e($dh->payment); ?></td>
<td><?php echo e($dh->note); ?></td>
<td><?php echo e($dh->state==0? "Chưa giao hàng": "Đã giao hàng"); ?></td>
<td class="center">
<i class="fa fa-pencil fa-fw"></i>
<a href="<?php echo e(route('editbills',$dh->id)); ?>">Cập nhật</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div></div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Admin/Billdanhsach.blade.php ENDPATH**/ ?>