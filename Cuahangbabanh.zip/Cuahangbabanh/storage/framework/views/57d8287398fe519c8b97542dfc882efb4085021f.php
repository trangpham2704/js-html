
<?php $__env->startSection("content"); ?>
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="login-panel panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Vui Lòng Đăng Nhập</h3>
<?php if(Session::has('matb')): ?>
<?php if(Session::get('matb')=='0'): ?>
<div class="alert alert-danger"><?php echo e(Session::get('noidung')); ?></div>
<?php endif; ?>
<?php endif; ?>
</div>
<div class="panel-body">
<form role="form" action="<?php echo e(route('adminlogin')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<fieldset>
<div class="form-group">
<input class="form-control" placeholder="Địa chỉ hộp thư" name="email" type="email" autofocus>
<?php if($errors->has('email')): ?>
<label style="color:red"><?php echo e($errors->first('email')); ?></label>
<?php endif; ?>
</div>
<div class="form-group">
<input class="form-control" placeholder="Mật Khẩu" name="password" type="password" value="">
<?php if($errors->has('password')): ?>
<label style="color:red"><?php echo e($errors->first('password')); ?></label>
<?php endif; ?>
</div>
<button type="submit" class="btn btn-lg btn-success btn-block">Đăng Nhập</button>
</fieldset>
</form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Admin/login.blade.php ENDPATH**/ ?>