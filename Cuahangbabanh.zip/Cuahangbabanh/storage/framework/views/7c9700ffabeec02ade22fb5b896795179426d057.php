
 <?php $__env->startSection("content"); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title"></h6>Loại <?php echo e($loai->name); ?></h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="index.html">Home</a> / <span><?php echo e($loai->name); ?></span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-3">
						<ul class="aside-menu">
						<?php $__currentLoopData = $dsloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="<?php echo e(route('loaisp', $dsl->id)); ?>"><?php echo e($dsl->name); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<div class="col-sm-9">
						<div class="beta-products-list">
						<h4>Danh sách sản phẩm thuộc loại <?php echo e($loai->name); ?></h4>
							<div class="beta-products-details">
							<p class="pull-left">Tìm thấy <?php echo e(count($sptheoloai)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>

							<div class="row">
<?php $__currentLoopData = $sptheoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sptl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-4">
									<div class="single-item">
									<?php if($sptl->promotion_price != 0): ?>
<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
<?php endif; ?>
										<div class="single-item-header">
											<a href="<?php echo e(route('chitietsp', $sptl->id)); ?>									"><img src="../resources/FrontEnd/image/product/<?php echo e($sptl->image); ?>" height="250"
="Hình Bánh"></a>
										</div>
										
										<div class="single-item-body">
										<p class="single-item-title"><?php echo e($sptl->name); ?></p>
											<p class="single-item-price">
<?php if($sptl->promotion_price==0): ?>
<span class="flash-sale"><?php echo e(number_format($sptl->unit_price)); ?> đồng</span>
<?php else: ?>
<span class="flash-del"><?php echo e(number_format($sptl->unit_price)); ?> </span>/
<span class="flash-sale"><?php echo e(number_format($sptl->promotion_price)); ?> đồng</span>
<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('addtocart', $sptl->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $sptl->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div> <!-- .beta-products-list -->

						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
							<h4>Sản phẩm khác</h4>
							<div class="beta-products-details">
							<p class="pull-left">Tìm Thấy <?php echo e(count($spkhac)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>
							<div class="row">
							<?php $__currentLoopData = $spkhac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-4">
									<div class="single-item">
										<div class="single-item-header">
										<a href="<?php echo e(route('chitietsp', $spk->id)); ?>"><img src="../resources/FrontEnd/image/product/<?php echo e($spk->image); ?>" height="250"
alt="Hình Bánh"></a>
										</div>
										<div class="single-item-body">
										<p class="single-item-title"><?php echo e($spk->name); ?></p>
											<p class="single-item-price">
											<?php if($spk->promotion_price==0): ?>
<span class="flash-sale"><?php echo e(number_format($spk->unit_price)); ?> đồng</span>
<?php else: ?>
<span class="flash-del"><?php echo e(number_format($spk->unit_price)); ?></span>/
<span class="flash-sale"><?php echo e(number_format($spk->promotion_price)); ?> đồng</span>
<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('addtocart', $spk->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $spk->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
<div class="row"><?php echo e($spkhac->links()); ?></div>
							<div class="space40">&nbsp;</div>
							
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->


			</div> <!-- .main-content -->
		</div> <!-- #content -->
	</div> <!-- .container -->


        <?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Pages/loaisanpham.blade.php ENDPATH**/ ?>