
 <?php $__env->startSection("content"); ?>
	<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Product</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="index.html">Chi tiết </a> / <span>Product</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>

	<div class="container">
		<div id="content">
			<div class="row">
				<div class="col-sm-9">

					<div class="row">
						<div class="col-sm-4">
							<img src="../resources/FrontEnd/image/product/<?php echo e($sanpham->image); ?>" alt="">
						</div>
						<div class="col-sm-8">
							<div class="single-item-body">
								<p class="single-item-title"><?php echo e($sanpham->name); ?></p>
								<p class="single-item-price">
								<?php if($sanpham->promotion_price==0): ?>
													<span class="flash-sale"><?php echo e($sanpham->unit_price); ?> </span>
								<?php else: ?>
												    <span class="flash-del"><?php echo e($sanpham->unit_price); ?> </span>
													<span class="flash-sale"><?php echo e($sanpham->promotion_price); ?> </span>
													<?php endif; ?>
								</p>
							</div>

							<div class="clearfix"></div>
							<div class="space20">&nbsp;</div>

							<div class="single-item-desc">
								<p>Các mBánh là loại món ăn làm bằng bột mì hay bột gạo có hương vị ngọt, mặn, béo...có thể hấp, nướng, chiên,... Bánh có nhiều cách chế biến khác nhau như: rán, chiên, nướng, hấp hoặc đôi khi là ăn sống. Thành phần và nguyên liệu của bánh rất đa dạng. Ngoài thành phần chính, bánh còn một số thành phần phụ như nước dùng, rau, đồ khô, kẹo, hoặc trái cây tươi, các loại hạt, kem. Một số loại bánh còn được trang trí rất công phu, tỉ mỉ.</p>
							</div>
							<div class="space20">&nbsp;</div>

							<p>Đơn vị tính</p>
<div class="single-item-options">
							<select class="wc-select" name="unit">
<option>Size</option>
<option value="Cái" <?php echo e($sanpham->unit=="cái"?"selected" : ""); ?>>Cái</option>

<option value="Hộp" <?php echo e($sanpham->unit=="hộp"? "selected" : ""); ?>>Hộp</option>

</select>
						
								<a class="add-to-cart" href="#"><i class="fa fa-shopping-cart"></i></a>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>

					<div class="space40">&nbsp;</div>
					<div class="woocommerce-tabs">
						<ul class="tabs">
							<li><a href="#tab-description">Description</a></li>
							<li><a href="#tab-reviews">Reviews (0)</a></li>
						</ul>

					
	
					<div class="panel" id="tab-description">
<p><?php echo $sanpham->description; ?></p>
</div>
</div>
<div class="space50">&nbsp;</div>
<div class="beta-products-list">

</h4>Sản phẩm tương tự</h4>

<div class="row">

<?php $__currentLoopData = $sptuongtu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sptt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-sm-4">
<div class="single-item">

<?php if($sptt->promotion_price != 0): ?>
<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
<?php endif; ?>

<div class="single-item-header">
<a href="<?php echo e(route('chitietsp', $sptt->id)); ?>"><img src="../resources/FrontEnd/image/product/<?php echo e($sptt->image); ?>" height="250" alt="Hình Bánh"></a>

</div>
<div class="single-item-body">

<p class="single-item-title"><?php echo e($sptt->name); ?></p>

<p class="single-item-price">

<?php if($sptt->promotion_price==0): ?>
<span class="flash-sale"><?php echo e(number_format($sptt->unit_price)); ?> đồng</span>
<?php else: ?>
<span class="flash-del"><?php echo e(number_format($sptt->unit_price)); ?> đồng</span>
<span class="flash-sale"><?php echo e(number_format($sptt->promotion_price)); ?> đồng</span>
<?php endif; ?>

</p>
</div>

<div class="single-item-caption">

<a class="add-to-cart pull-left" href="<?php echo e(route('addtocart', $sptt->id)); ?>"><i class="fa fa-shopping-cart"></i></a>

<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $sptt->id)); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>

<div class="clearfix"></div>
</div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="row"><?php echo e($sptuongtu->links()); ?></div>

</div> <!-- .beta-products-list -->
</div>
<div class="col-sm-3 aside">
<div class="widget">
<h3 class="widget-title">Sản phẩm bán chạy</h3>
<div class="widget-body">
<div class="beta-sales beta-lists">

<?php $__currentLoopData = $spbanchay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spbc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="media beta-sales-item">

<a class="pull-left" href="route('chitietsp', $spbc->id_product)">
<img src="../resources/FrontEnd/image/product/<?php echo e($spbc->products->image); ?>" alt=""></a>
<div class="media-body">

<?php echo e($spbc->products->name); ?><br>
<?php if($spbc->products->promotion_price==0): ?>
<span class="flash-sale"><?php echo e(number_format($spbc->products->unit_price)); ?> đồng</span>
<?php else: ?>
<span class="flash-del"><?php echo e(number_format($spbc->products->unit_price)); ?> đồng</span><br>
<span class="flash-sale"><?php echo e(number_format($spbc->products->promotion_price)); ?> đồng</span>
<?php endif; ?>

</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div> <!-- best sellers widget -->
<div class="widget">
<h3 class="widget-title">Sản phẩm mới</h3>
<div class="widget-body">
<div class="beta-sales beta-lists">

<?php $__currentLoopData = $spmoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="media beta-sales-item">

<a class="pull-left" href="<?php echo e(route('chitietsp', $spm->id)); ?>">
<img src="../resources/FrontEnd/image/product/<?php echo e($spm->image); ?>" alt="">
</a>
<div class="media-body">
<?php echo e($spm->name); ?><br>
<?php if($spm->promotion_price==0): ?>
<span class="flash-sale"><?php echo e(number_format($spm->unit_price)); ?> đồng</span>
<?php else: ?>
<span class="flash-del"><?php echo e(number_format($spm->unit_price)); ?> đồng</span><br>
<span class="flash-sale"><?php echo e(number_format($spm->promotion_price)); ?> đồng</span>
<?php endif; ?>

</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div> <!-- best sellers widget -->

</div>
</div>
</div> <!-- #content -->
</div> <!-- .container -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Pages/chitietsanpham.blade.php ENDPATH**/ ?>