 
 <?php $__env->startSection("content"); ?>
<!-- #header -->
<div class="rev-slider">
	<div class="fullwidthbanner-container">
					<div class="fullwidthbanner">
						<div class="bannercontainer" >
					    <div class="banner" >
								<ul>
								<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<!-- THE FIRST SLIDE -->
									<li data-transition="boxfade" data-slotamount="20" class="active-revslide" style="width: 100%; height: 100%; overflow: hidden; z-index: 18; visibility: hidden; opacity: 0;">
						            <div class="slotholder" style="width:100%;height:100%;" data-duration="undefined" data-zoomstart="undefined" data-zoomend="undefined" data-rotationstart="undefined" data-rotationend="undefined" data-ease="undefined" data-bgpositionend="undefined" data-bgposition="undefined" data-kenburns="undefined" data-easeme="undefined" data-bgfit="undefined" data-bgfitend="undefined" data-owidth="undefined" data-oheight="undefined">
													<div class="tp-bgimg defaultimg" data-lazyload="undefined" data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat" data-lazydone="undefined" src="../resources/FrontEnd/image/slide/<?php echo e($sl->image); ?>" data-src="../resources/FrontEnd/image/slide/<?php echo e($sl->image); ?>" style="background-color: rgba(0, 0, 0, 0); background-repeat: no-repeat; background-image: url('../resources/FrontEnd/image/slide/<?php echo e($sl->image); ?>'); background-size: cover; background-position: center center; width: 100%; height: 100%; opacity: 1; visibility: inherit;">
													</div>
												</div>

						        </li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>
						<div class="tp-bannertimer"></div>
					</div>
	</div>
</div>
				<!--slider-->

	<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4>Sản phẩm mới</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm Thấy : <?php echo e(count($newsp)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>

							<div class="row">
							<?php $__currentLoopData = $newsp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $np): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">
										<div class="single-item-header">
											<a href="<?php echo e(route('chitietsp', $np->id)); ?>"><img height="250" src="../resources/FrontEnd/image/product/<?php echo e($np->image); ?>" alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($np->name); ?> </p>
											<p class="single-item-price">
												<?php if($np->promotion_price==0): ?>
													<span class="flash-sale"><?php echo e($np->unit_price); ?> </span>
												<?php else: ?>
												    <span class="flash-del"><?php echo e($np->unit_price); ?> </span>
													<span class="flash-sale"><?php echo e($np->promotion_price); ?> </span>
													<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
 										<a class="add-to-cart" href="<?php echo e(route('addtocart', $np->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $np->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
							<div class="row" align="right"><?php echo e($newsp->appends(['pagenor'=>$spsale->currentPage()])->links()); ?>

								
							</div>
						</div> <!-- .beta-products-list -->

						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
							<h4>Sản phẩm Khuyến mãi </h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm Thấy : <?php echo e(count($spsale)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>
							<div class="row">
							<?php $__currentLoopData = $spsale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">
										<div class="single-item-header">
											<a href="<?php echo e(route('chitietsp', $sale->id)); ?>"><img height="250" src="../resources/FrontEnd/image/product/<?php echo e($sale->image); ?>" alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title" style="font-size:16px"><?php echo e($sale->name); ?></p>
											<p class="single-item-price">
											<?php if($sale->promotion_price==0): ?>
													<span class="flash-sale"><?php echo e($sale->unit_price); ?> </span>
												<?php else: ?>
												    <span class="flash-del"><?php echo e($sale->unit_price); ?> </span>
													<span class="flash-sale"><?php echo e($sale->promotion_price); ?> </span>
													<?php endif; ?>
											</p>

										</div>
										<div class="single-item-caption">
										<a class="add-to-cart" href="<?php echo e(route('addtocart', $sale->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('chitietsp', $sale->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							</div>
							<div class="row" align="right"><?php echo e($newsp->appends(['pagenor'=>$spsale->currentPage()])->links()); ?>

								
							</div>
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->
			</div> <!-- .main-content -->
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Pages/trangchu.blade.php ENDPATH**/ ?>