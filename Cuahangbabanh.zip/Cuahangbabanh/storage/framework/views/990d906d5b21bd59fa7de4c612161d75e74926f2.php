
<?php $__env->startSection("content"); ?>
<div id="page-wrapper">
        <div class="container-fluid">
<div style="width:100%; float:left; font-family: Helvetica; font-size:13px">

<div style="float: left;">
<strong style="font-size: 18px;">Tiệm Bánh Yêu Thương</strong><br />
<strong>Địa chỉ:</strong> 47N Hoàng Quốc Việt, Phường Phú Mỹ, Quận 07 , TP.HCM , Việt Nam<br />
<strong>Điện Thoại</strong> 0934100453<br />
<strong>Website:</strong>www.red4estd@<br />
<strong>Email:</strong> shop.yeuthuong@gmail.com
</div>
<div style="clear:both"></div>
<table style="width: 100%">
<tr>
<td valign="top" style="padding: 0px; width: 45%; ">
<h3 style="font-size: 14px;margin: 1.5em 0 3px 0;">Thông tin Khách Hàng</h3>

<hr style="border: none; border-top: 2px solid #0975BD;margin-bottom:3px;margin-top:3px;" />
<div>
<strong><?php echo e($cus->name); ?></strong><br />
Địa chỉ: <?php echo e($cus->address); ?><br />
Điện thoại: <?php echo e($cus->phone); ?><br />
Email: <?php echo e($cus->email); ?>

</div>

</td>


<input class="btn btn-primary" type="submit" name="capnhat" value="Cập Nhật" />
</p>
</form>

</td>
</tr>
</table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Admin/Custume_chitiet.blade.php ENDPATH**/ ?>