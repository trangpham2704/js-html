
<?php $__env->startSection("content"); ?>
<!-- Page Content -->
<div id="page-wrapper">
        <div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<h1 class="page-header">DANH SÁCH KHÁCH HÀNG</h1>
</div>
<!-- /.col-lg-12 -->
<table class="table table-striped table-bordered table-hover" style="font-size:12px">
<thead>
<tr align="center">
<th>Mã Khách Hàng</th>
<th>Tên Khách Hàng</th>
<th>Phái</th>
<th>Email</th>
<th>Địa chỉ</th>
<th>Số điện thoại</th>
<th>Thao tác</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $khachhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="odd gradeX" align="center">
<td><?php echo e($kh->id); ?></td>
<td><?php echo e($kh->name); ?></td>
<td><?php echo e($kh->gender); ?></td>
<td><?php echo e($kh->email); ?></td>
<td><?php echo e($kh->address); ?></td>
<td><?php echo e($kh->phone_number); ?></td>
<td class="center">
<i class="fa fa-pencil fa-fw"></i>
<a href="<?php echo e(route('editKH',$kh->id)); ?>">Cập nhật</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div></div>
<!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHPnangcao\Laravel\Cuahangbabanh\resources\views/Admin/Custume_danhsach.blade.php ENDPATH**/ ?>